package understanding_selenium.kt;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class lamda_expression_flipkart {

	@Test
public void lamda_expression_flipkart()
{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\10738163\\eclipse-workspace\\selenium_assignment_stock_prices_flipkart\\chrome_driver\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();		
		
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		
		List<String> allLinksHrefs = driver.findElements(By.tagName("a"))		 
				.stream()				
				.map(link -> link.getAttribute("href")) 
				.collect(Collectors.toList());				
		
		allLinksHrefs.forEach(System.out::println);				
		driver.quit();	
}

}
