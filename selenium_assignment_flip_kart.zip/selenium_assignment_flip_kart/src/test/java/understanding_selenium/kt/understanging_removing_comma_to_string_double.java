package understanding_selenium.kt;

public class understanging_removing_comma_to_string_double {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String numberString = "10,000"; 
		numberString = numberString.replace(",", ""); // Remove the comma 
		double number = Double.parseDouble(numberString); // Parse the string as a double 
		System.out.println(number);
	}

}
