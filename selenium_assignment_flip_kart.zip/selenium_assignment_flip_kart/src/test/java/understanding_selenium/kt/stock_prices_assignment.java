package understanding_selenium.kt;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.checkerframework.common.value.qual.ArrayLen;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class stock_prices_assignment {

	@Test
	public void stock_prices_assignment() throws InterruptedException, IOException
	{

		FileInputStream file = new FileInputStream("C:\\Users\\10738163\\eclipse-workspace\\selenium_kt\\test_data_understanding\\file_to_fetch_data_to_console.xlsx");
		  XSSFWorkbook wb = new XSSFWorkbook(file); 
	        XSSFSheet sh = wb.getSheet("Sheet1");
	        
	        HashMap<String, Double> map_excel_sheet = new HashMap<String, Double>();
	        
	        int last_row_num = sh.getLastRowNum();
	        
	        for (int r = 0; r <= 10; r++) 
	        { 
	        	String key = (String)sh.getRow(r) 
	                             .getCell(0) 
	                               .getStringCellValue(); 
	            
	        	Double value = (Double) sh.getRow(r) 
	                               .getCell(1) 
	                                  .getNumericCellValue();
	            
	        	map_excel_sheet.put(key, value); 
	        } 
	          
	     // Displaying HashMap 
	        Iterator<Entry<String, Double> > new_Iterator = map_excel_sheet.entrySet().iterator(); 
	  
	        System.out.println();
	        System.out.println(" ******** ******** ******** ******** ******** data from excel sheet ******** ******** ******** ******** ********");
	        System.out.println();
	        
	        while (new_Iterator.hasNext()) 
	        { 
	            Map.Entry<String, Double> new_Map = (Map.Entry<String, Double>) 
	                      new_Iterator.next(); 
	            
	            System.out.println(new_Map.getKey() + " ----> "
	                               + new_Map.getValue()); 
	        } 
	        wb.close(); 
	        file.close();
	  
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\10738163\\eclipse-workspace\\selenium_kt\\chrome_driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://money.rediff.com/gainers/bse/monthly/groupall");
		
		driver.manage().window().maximize();
		
		List<WebElement> company_names = driver.findElements(By.xpath("//td[1]"));
		
		ArrayList<String> arr_list_company_name = new ArrayList<String>();
		
		for (WebElement x : company_names) 
		{
			String str = x.getText();
			
			arr_list_company_name.add(str);
		}
		
		List<WebElement> current_price = driver.findElements(By.xpath("//td[4]"));
		
		ArrayList<Double> arr_list_current_price = new ArrayList<Double>();
		
		int count=0;

		for (WebElement y : current_price) 
		{
			if (count <= 10)
			{
				String current_prices = y.getText();

			       String s1 = current_prices.replaceAll(",","").trim(); 
      
			       String f = s1.replaceAll(" ", ""); 

			       Double d=Double.valueOf(f);
			       
				arr_list_current_price.add(d);
			}
			count++;
        }
		
		HashMap<String, Double> map_web_table = new HashMap<>();
		
		int len = arr_list_company_name.size();
		
		for(int i = 0; i < 10; i++) 
		{
			map_web_table.put(arr_list_company_name.get(i), arr_list_current_price.get(i));
		}

        System.out.println();
        System.out.println(" ******** ******** ******** ******** ******** data from WEB PAGE ******** ******** ******** ******** ********");
        System.out.println();
        
        for (Entry<String, Double> entry : map_web_table.entrySet()) 
        {
            System.out.println(entry.getKey() + " ----> " + entry.getValue());
        }

        int rowno=0; 
        
        XSSFWorkbook work_book = new XSSFWorkbook(); 
        XSSFSheet she_et = work_book.createSheet("understanding_excel_selenium_automation"); 
        
        for(HashMap.Entry entry : map_web_table.entrySet()) 
        { 
            XSSFRow row = she_et.createRow(rowno++); 
            row.createCell(0).setCellValue((String)entry.getKey()); 
            row.createCell(1).setCellValue((Double)entry.getValue()); 
        } 
 
        FileOutputStream file1 = new FileOutputStream("C:\\Users\\10738163\\eclipse-workspace\\selenium_assignment_stock_prices_flipkart\\file_write_web_table_1.xlsx"); 
        work_book.write(file1); 
        file1.close(); 
        
        System.out.println("******** ******** ******** ******** ********");
        System.out.println();
        System.out.println("Data succesfully Copied to Excel file named as file_write_web_table.xlsx "); 
        System.out.println();
        System.out.println("******** ******** ******** ******** ********");
	}
}
