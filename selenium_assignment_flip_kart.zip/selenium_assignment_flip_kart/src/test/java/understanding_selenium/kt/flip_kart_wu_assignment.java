package understanding_selenium.kt;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class flip_kart_wu_assignment 
{

	@Test
public void flip_kart_wu_assignment() throws InterruptedException
{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\10738163\\eclipse-workspace\\selenium_assignment_stock_prices_flipkart\\chrome_driver\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	Thread.sleep(5000);
	
	driver.get("https://www.flipkart.com/");
	Thread.sleep(5000);
	
	driver.manage().window().maximize();
	Thread.sleep(5000);

	 List<WebElement> allLinks = driver.findElements(By.tagName("a"));

	 for(WebElement link : allLinks)
	 {
	 Thread.sleep(1000);
	 System.out.println(link.getText() + " - " + link.getAttribute("href"));
	 }
}
	
}
